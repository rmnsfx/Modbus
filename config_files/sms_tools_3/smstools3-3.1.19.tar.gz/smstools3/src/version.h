#ifndef VERSION_H
#define VERSION_H

#define smsd_version    "3.1.19"

#endif
